package Elaboration;

public enum Type {
	Int,
	Bool,
	IntArray,
	BoolArray,
	NotInScope,
	Empty;
}
