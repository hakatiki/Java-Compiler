package Generation;

public class TooManyThreadsException extends Throwable {
    public TooManyThreadsException(String s) {
        super(s);
    }
}
