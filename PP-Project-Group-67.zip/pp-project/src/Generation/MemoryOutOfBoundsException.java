package Generation;

public class MemoryOutOfBoundsException extends Exception {

    MemoryOutOfBoundsException(String s) {
        super(s);
    }
}
