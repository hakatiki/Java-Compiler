-- this file is used by the cabal tool
-- to install this package use the command: cabal install
import Distribution.Simple
main = defaultMain
