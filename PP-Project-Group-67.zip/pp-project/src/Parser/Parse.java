package Parser;

import ANTLR.GrammarBaseListener;

public class Parse extends GrammarBaseListener { } //empty by design
